def endOfDirectory(a,b):
    pass